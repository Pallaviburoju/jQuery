$(function () {
    //DOM is loaded
    initialize();
});

var initialize = function () {
    jQueryUIInitializations();
    wireEvents();
}

var jQueryUIInitializations = function () {
    /*jQueryUi - Buttons */
    $('#btnSimpleDialog').button();
    $('#btnModalDialog').button();

    /*Simple Dialog */
    $('#simpleDialog').dialog({ autoOpen: false });

    /*Modal Dialog */
    $('#modalDialog').dialog({
        autoOpen: false,
        modal: true,
        resizable: false,
        draggable: false,
        buttons: {
            "OK": function () {
                $(this).dialog('close');
                $('#modalTarget').text('OK Pressed');
            },
            "Cancel": function () {
                $('#modalDialog').dialog('close');
                $('#modalTarget').text('Cancel Pressed');
            }
        }
    });

    /*DatePicker*/
    $('input[data-site-datepicker="true"]').each(createDatePicker);

    /*accordion*/
    $('#accordion').accordion({ autoHeight: false, collapsible: true });

    /*Slider Initialization */
    $('#sliderRed').slider({ min: 0, max: 255, value: 0, slide: changeSliderValue });
    $('#sliderBlue').slider({ min: 0, max: 255, value: 0, slide: changeSliderValue });
    $('#sliderGreen').slider({ min: 0, max: 255, value: 0, slide: changeSliderValue });
}

var wireEvents = function () {
    $('#btnSimpleDialog').bind('click', function () {
        $('#simpleDialog').dialog('open');
    });

    $('#btnModalDialog').bind('click', function () {
        $('#modalDialog').dialog('open');
    });
}

/*Helper Functions*/

var createDatePicker = function () {
    $input = $(this);
    var options = {
        dateFormat: 'd/m/yy',
        showAnim: 'explode',
        numberOfMonths: 1,
        showWeek: true,
        changeMonth: true,
        changeYear: true,
        minDate: new Date(2016, 0, 1),
        maxDate: new Date(2020, 11, 31),
        showButtonPanel: true,
        showTodayButton: true
    }
    $input.datepicker(options);
    $input.datepicker('setDate', new Date());
}

var r = 0, g = 0, b = 0;
var changeSliderValue = function (event, ui) {
    if (event.target.id == "sliderRed") {
        r = ui.value;
        $('#spanRed').text(r);
    }
    if (event.target.id == "sliderBlue") {
        b = ui.value;
        $('#spanBlue').text(b);
    }
    if (event.target.id == "sliderGreen") {
        g = ui.value;
        $('#spanGreen').text(g);
    }
    $('#colorDiv').css({ "background-color": "rgb(" + r + "," + g + "," + b + ")" })
}